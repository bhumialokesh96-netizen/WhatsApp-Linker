package main

import (
	"context"
	"fmt"
	"log"
	"net/http"

	_ "github.com/mattn/go-sqlite3"
	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	waProto "go.mau.fi/whatsmeow/proto/waE2E"
	"google.golang.org/protobuf/proto"
)

var client *whatsmeow.Client

func main() {
	// 1. Initialize SQLite Database (session.db) - Added context.Background() here
	dbLog := waLog.Stdout("Database", "WARN", true)
	container, err := sqlstore.New(context.Background(), "sqlite3", "file:session.db?_foreign_keys=on", dbLog)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}

	// 2. Get or create a device session - Added context.Background() here
	deviceStore, err := container.GetFirstDevice(context.Background())
	if err != nil {
		log.Fatalf("Failed to get device store: %v", err)
	}

	// 3. Initialize WhatsMeow Client
	clientLog := waLog.Stdout("Client", "WARN", true)
	client = whatsmeow.NewClient(deviceStore, clientLog)
	client.AddEventHandler(eventHandler)

	// 4. Setup HTTP Routes
	http.HandleFunc("/", handleIndex)
	http.HandleFunc("/pair", handlePair)
	http.HandleFunc("/status", handleStatus)
	http.HandleFunc("/send", handleSend)

	fmt.Println("Server running on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

// Event handler for incoming messages
func eventHandler(evt interface{}) {
	switch v := evt.(type) {
	case *events.Message:
		fmt.Println("Received a message from:", v.Info.Sender.User)
	case *events.Connected:
		fmt.Println("Connected to WhatsApp WebSocket.")
	case *events.PairSuccess:
		fmt.Println("Successfully paired via phone number!")
	}
}

// Serve the HTML page
func handleIndex(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "index.html")
}

// Generate Pairing Code
func handlePair(w http.ResponseWriter, r *http.Request) {
	phone := r.URL.Query().Get("phone")
	if phone == "" {
		http.Error(w, "Phone number is required", http.StatusBadRequest)
		return
	}

	if client.Store.ID != nil {
		w.Write([]byte("Already linked."))
		return
	}

	if !client.IsConnected() {
		err := client.Connect()
		if err != nil {
			http.Error(w, "Failed to connect: "+err.Error(), http.StatusInternalServerError)
			return
		}
	}

	code, err := client.PairPhone(r.Context(), phone, true, whatsmeow.PairClientChrome, "Chrome (Linux)")
	if err != nil {
		http.Error(w, "Failed to get pairing code: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte(code))
}

// Check Connection Status
func handleStatus(w http.ResponseWriter, r *http.Request) {
	if client.Store.ID != nil {
		w.Write([]byte("Linked"))
	} else {
		w.Write([]byte("Not Linked"))
	}
}

// Send a Message
func handleSend(w http.ResponseWriter, r *http.Request) {
	targetPhone := r.URL.Query().Get("phone")
	msgText := r.URL.Query().Get("text")

	if targetPhone == "" || msgText == "" {
		http.Error(w, "Missing phone or text parameter", http.StatusBadRequest)
		return
	}

	targetJID := types.NewJID(targetPhone, "s.whatsapp.net")
	msg := &waProto.Message{
		Conversation: proto.String(msgText),
	}

	_, err := client.SendMessage(context.Background(), targetJID, msg)
	if err != nil {
		http.Error(w, "Failed to send message: "+err.Error(), http.StatusInternalServerError)
		return
	}

	w.Write([]byte("Message sent successfully!"))
}












